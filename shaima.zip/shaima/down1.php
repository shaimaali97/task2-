<?php include('connect1.php'); ?>
<?php 
	
    if(isset($_GET['direction']))
    {
        $direction = $_GET['direction'];

        if($direction != "delete")
        {
            $udregistrationsql = "INSERT INTO `direction` (`id`, `dirname`) VALUES (NULL, '$direction');";
            $resReg = mysqli_query($conn,$udregistrationsql);
            $count = mysqli_affected_rows($conn);
        }
    }
?>

<!DOCTYPE html>
<html>
    <head> 
        <link rel="stylesheet" href="style1.css" />
    </head>

<body contenteditable="false">

 

<h1>D</h1>

<br>
<br>
<br>
    
    <br>
<br>
    <br>

<br>
<br>
<a href="up1.php?direction=U" class="button" style="width:20%;">Up</a> 
<br>
<br>
<a href="left1.php?direction=L" class="button1" style="width:20%;">Left</a> 
<a href="stop1.php?direction=Delete" class="button4" style="width:20%;">Stop</a> 
<a href="right1.php?direction=R" class="button2" style="width:20%;">Right</a>
<br>
<br>
<a href="down1.php?direction=D" class="button3" style="width:20%;">Down</a> 
 

</body> </html>